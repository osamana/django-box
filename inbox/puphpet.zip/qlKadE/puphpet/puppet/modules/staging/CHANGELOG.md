## 2016/06/10 - Release 2.0.0

* Drop of Ruby1.8 support!
* modulesync to latest voxpupli configs
* Add support for OpenBSD
* Allow to pass in the full path to a file instead of specifying the file name explictly
* Revocation of 1.0.6 (wrong semver)

## 2016/06/10 - Release 1.0.7

* Last Release with Ruby1.8 support!

## 2016/03/20 - Release 1.0.6

* Publish the first version of this module in the puppet namespace.
* Accidently removed Ruby1.8 support
